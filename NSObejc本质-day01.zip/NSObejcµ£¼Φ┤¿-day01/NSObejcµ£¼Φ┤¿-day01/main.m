//
//  main.m
//  NSObejc本质-day01
//
//  Created by iOS1 on 2021/3/8.
///Users/ios1/Desktop/博客demo/NSObejc本质-day01/NSObejc本质-day01/main.m

#import <Foundation/Foundation.h>
#import <malloc/malloc.h>
#import <objc/runtime.h>

////commend+右键查看，NSObject定义
//@interface NSObject  {
//#pragma clang diagnostic push
//#pragma clang diagnostic ignored "-Wobjc-interface-ivars"
//    Class isa  OBJC_ISA_AVAILABILITY;
//#pragma clang diagnostic pop
//}
//@end

//main-arm64.cpp可以搜索下面这个，NSObject的实现
//struct NSObject_IMPL {
////    8个字节
//    Class isa;
//
//};
//
struct NSObjectTest2 {
    Class isa;
    int num;
    int height;
    int wight;
};

@interface person : NSObject
{
    
    @public
    int _no;
    int _age;
    
}
@end

@implementation person
@end

@interface student : person
{
    int width;
}
@end
@implementation student
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSObject *obj = [[NSObject alloc]init];
        
        //获取NSObject类的实例对象的大小 >> 8
        NSLog(@"%zd",class_getInstanceSize([NSObject class]));
        
        //获取obj指针所指向的内存大小 >> 16
        NSLog(@"%zu",malloc_size((__bridge const void *)(obj)));
    }
    return 0;
}
